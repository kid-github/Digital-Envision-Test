export { default } from './components/Discover';
